package com.mastek.login.model;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
