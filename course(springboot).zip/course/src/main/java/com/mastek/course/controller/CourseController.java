package com.mastek.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mastek.course.model.Course;
import com.mastek.course.service.CourseService;

@RestController
@RequestMapping("/course")
@CrossOrigin(origins="http://localhost:4200")

public class CourseController {
	
	@Autowired(required= true)
	CourseService service;
	
	@GetMapping("/courses")
	public Iterable<Course> findAll () {
		return service.findAll();
	}
	
	@GetMapping("/course/{course_id}")
	public Course findById(@PathVariable int course_id) {
		return service.findById(course_id);
	}
	
	@PostMapping ("/courses/save")
	public String save(
	@RequestBody Course course ){
		return service.save(course);
	}
	
	
	
	@DeleteMapping("/courses/delete/{course_id}")
	public String delete(@PathVariable int course_id) {
		return service.deleteById(course_id);
	}
	


}
