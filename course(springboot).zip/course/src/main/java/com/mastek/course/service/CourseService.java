package com.mastek.course.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mastek.course.model.Course;
import com.mastek.course.repository.CourseRepository;




@Service
public class CourseService {
	
	@Autowired(required=true)
	
	private CourseRepository repository;
	
	public Iterable<Course> findAll() {
		return repository.findAll();
	}
	
	public Course findById(int id) {
		return repository.findById(id).get();
		
	}
	
//	public String add(int courseId, String courseName , String link, String description) {
//		return repository.add(new Course ( courseId, courseName, link, description));
//	}
	
	public String deleteById(int id) {
		repository.deleteById(id);
		return "deleted";
	}
	
	
	public String save(Course entity) {
		Course newCourse=repository.save(entity);
		return "saved"+newCourse;
	}
	
	
	

}
