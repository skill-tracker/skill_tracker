package com.mastek.login.security.services;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mastek.login.model.Course;
import com.mastek.login.repository.ICourseRepository;

@Service
public class CourseService {
	
	@Autowired(required=true)
	
	private ICourseRepository repository;
	
	public Iterable<Course> findAll() {
		return repository.findAll();
	}
	
	public String save(Course entity) {
		System.out.println("Course create called from service");
		Course newCourse=repository.save(entity);
			return "added course "+newCourse;
		}
	
	public String deleteById(int course_id) {
		System.out.println("Course delete called from service");
		repository.deleteById(course_id);
		return "deleted course "+course_id;
	}
	
		

}
