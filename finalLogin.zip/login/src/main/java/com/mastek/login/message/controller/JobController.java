package com.mastek.login.message.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mastek.login.model.Job;
import com.mastek.login.security.services.JobService;

@RestController
@CrossOrigin(origins= "http://localhost:4200")
@RequestMapping("/api")
public class JobController {	
	@Autowired
	JobService service;
	
	@GetMapping("/test/jobs")
	public Iterable<Job> findAll(){
		System.out.println("Fetch job called from job controller  ");
		return service.findAll();
	}
	
	@PostMapping(value="/test/jobs/create")
	public String save(@RequestBody Job job){
		System.out.println("Create job called from  job controller");
		return service.save(job);
		
	}
	@DeleteMapping({"/test/jobs/delete/{job_id}"})
	public ResponseEntity<String> deleteJobById(@PathVariable("job_id") int job_id){
		System.out.println("Delete job called from job controller");
		System.out.println("deleting job -> "+job_id);
		service.deleteById(job_id);
		return ResponseEntity.ok("deleted job "+job_id); 
	}
}
