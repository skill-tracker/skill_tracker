package com.mastek.login.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
//POJO created to provide table definition in database.
@Entity
@Table(name="job")
public class Job {
	@Id
	private int job_id;
	private String job_title;
	private String company_name;
	private String job_desc;
	private String job_url;
	public Job() {
		super();
	}
	public Job(int job_id, String job_title, String company_name, String job_desc, String job_url) {
		super();
		this.job_id = job_id;
		this.job_title = job_title;
		this.company_name = company_name;
		this.job_desc = job_desc;
		this.job_url = job_url;
	}
	public int getJob_id() {
		return job_id;
	}
	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}
	public String getJob_title() {
		return job_title;
	}
	public void setJob_title(String job_title) {
		this.job_title = job_title;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getJob_desc() {
		return job_desc;
	}
	public void setJob_desc(String job_desc) {
		this.job_desc = job_desc;
	}
	public String getJob_url() {
		return job_url;
	}
	public void setJob_url(String job_url) {
		this.job_url = job_url;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + job_id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Job other = (Job) obj;
		if (job_id != other.job_id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Job [job_id=" + job_id + ", job_title=" + job_title + ", company_name=" + company_name + ", job_desc="
				+ job_desc + ", job_url=" + job_url + "]";
	}
	
	
	
	
}
