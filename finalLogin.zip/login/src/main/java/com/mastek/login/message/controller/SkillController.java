package com.mastek.login.message.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mastek.login.model.Skill;
import com.mastek.login.security.services.SkillService;

@CrossOrigin(origins= {"http://localhost:4200"})
@RequestMapping("/api")
@RestController
public class SkillController {
	
	@Autowired(required=true)
	SkillService service;
	
	@GetMapping("/test/skills")
	public Iterable<Skill> findAll(){
		System.out.println("fetch skills called from skill controller");
		return service.findAll();
	}
	
	@PostMapping("/test/skills/create")
	public String save(@RequestBody Skill skill) {
		System.out.println("create skill called from skill controller ");
		return service.save(skill);
	}
	
	@DeleteMapping({"/test/skills/delete/{skill_id}"})
	public ResponseEntity<String> deleteSkillById(@PathVariable("skill_id") int skill_id){
		System.out.println("Delete skill called from skill controller");
		System.out.println("deleting skill -> "+skill_id);
		service.deleteById(skill_id);
		return ResponseEntity.ok("deleted "+skill_id); 
	}
	
	
	@PutMapping("/test/skills/update/{skill_id}")
	public ResponseEntity<String> updateSkill(@PathVariable("skill_id") int skill_id, @RequestBody Skill skill ){
		System.out.println("Update skill  called skill controller");
		Optional<Skill> skillData=service.findById(skill_id);
		if(skillData.isPresent()) {
			Skill skill1=skillData.get();
			skill1.setPriority(skill.getPriority());
			String message= service.save(skill1);
			return ResponseEntity.ok("updated skill");
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
		}
		
	}

}