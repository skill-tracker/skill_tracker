package com.mastek.login.security.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.mastek.login.model.Job;
import com.mastek.login.repository.IJobRepository;

@Service
public class JobService {
	@Autowired
	private IJobRepository repository;
	
	public Iterable<Job> findAll(){
		System.out.println("Job fetch called from service");
		return repository.findAll();
	}
	
	public String save(Job entity) {
		System.out.println("Job  create called from service");
			 Job newJob =  repository.save(entity);
			 return " job added "+ newJob;
		 }

	public String deleteById(int job_id) {
		System.out.println("Job delete called from service");
		repository.deleteById(job_id);
		return " job deleted"+ job_id;
	}
}

	
	

