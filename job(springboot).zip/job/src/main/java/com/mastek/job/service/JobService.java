package com.mastek.job.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mastek.job.model.Job;
import com.mastek.job.repository.IJobRepository;

@Service
public class JobService {
	@Autowired(required=true)
	IJobRepository repository;
	
	public Iterable<Job> findAll(){
		return repository.findAll();
	}
	
	public Job findById(int job_id) {
		return repository.findById(job_id).get();
	}
	
	public String deleteById(int  job_id) {
		repository.deleteById(job_id);
		return "deleted";
	}
	 public String save(Job entity) {
		 Job newJob =  repository.save(entity);
		 return "added "+ newJob;
	 }
}
