package com.mastek.job.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mastek.job.model.Job;
@Repository
public interface IJobRepository extends CrudRepository<Job, Integer> {

}
